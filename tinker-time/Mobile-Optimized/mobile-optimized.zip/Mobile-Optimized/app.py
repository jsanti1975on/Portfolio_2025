from __future__ import annotations
import os, csv, datetime as dt, re
from pathlib import Path
from flask import Flask, render_template, request, redirect, url_for, flash
import netifaces as ni

APP_SECRET = os.environ.get("APP_SECRET", "dev-secret-change-me")
DATA_DIR = Path(os.environ.get("DATA_DIR", str(Path(__file__).parent / "data"))).resolve()
DATA_DIR.mkdir(parents=True, exist_ok=True)
CSV_PATH = DATA_DIR / "cash_tendered.csv"

app = Flask(__name__)
app.secret_key = APP_SECRET

CURRENCY_RE = re.compile(r"^\$?\s*([0-9]+(?:\.[0-9]{1,2})?)$")

def host_ips():
    out = []
    for iface in ni.interfaces():
        addrs = ni.ifaddresses(iface).get(ni.AF_INET, [])
        for a in addrs:
            ip = a.get("addr")
            if ip and not ip.startswith("127."):
                out.append((iface, ip))
    return out

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        raw = (request.form.get("cash_tendered") or "").strip()
        m = CURRENCY_RE.match(raw)
        if not m:
            flash("Enter an amount like 12.34", "error")
            return redirect(url_for("index"))
        amount = float(m.group(1))
        if amount <= 0:
            flash("Amount must be > 0", "error")
            return redirect(url_for("index"))
        amount = round(amount, 2)

        ts = dt.datetime.now().isoformat(timespec="seconds")
        new_file = not CSV_PATH.exists()
        with CSV_PATH.open("a", newline="") as f:
            w = csv.writer(f)
            if new_file:
                w.writerow(["timestamp", "amount"])
            w.writerow([ts, f"{amount:.2f}"])
        flash(f"Saved ${amount:.2f}", "ok")
        return redirect(url_for("index"))

    return render_template("index.html", ips=host_ips(), data_dir=str(DATA_DIR))

@app.get("/healthz")
def healthz():
    return {"ok": True, "data_dir": str(DATA_DIR)}

if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5000"))
    app.run(host="0.0.0.0", port=port, debug=True)
