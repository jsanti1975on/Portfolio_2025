# Mobile-Optimized – Cash Tendered (Flask)

A tiny mobile-friendly Flask app that records a "Cash Tendered" amount to a CSV.
It shows local interface IPs using `netifaces` and saves to `./data/cash_tendered.csv`
by default (override with `DATA_DIR`).

## Quickstart

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export DATA_DIR="$(pwd)/data"
python app.py  # then visit http://localhost:5000
```

## Production (Gunicorn example)

```bash
. .venv/bin/activate
export DATA_DIR="$(pwd)/data"
export APP_SECRET="change-me"
gunicorn -w 2 -b 0.0.0.0:8000 app:app
```

## Env Vars
- `DATA_DIR` – directory to store CSV (default: ./data)
- `APP_SECRET` – Flask secret key (default is a dev placeholder; change in prod)
- `PORT` – used only when running `python app.py` (default: 5000)
